<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ms_videofield}prestashop>ms_videofield_fefab0a59036e7ff3a65dae8936e7173'] = 'Dodatkowy opis produktu';
$_MODULE['<{ms_videofield}prestashop>ms_videofield_7f4a810ee042b3d93f303504d3830fd5'] = 'Dodanie nowej zakładki opisowej w karcie produktu';
$_MODULE['<{ms_videofield}prestashop>ms_videofield_05adc86c7cd48389de038ef75850a444'] = 'Dodatkowa zakładka';
$_MODULE['<{ms_videofield}prestashop>ms_videofield_8e753068ca410f0f695f0dd52a975c20'] = 'Nazwa zakł.';
